package esercizioB;

import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class main {

	public static void main(String[] args) {
		
		 Scanner numero = new Scanner(System.in);
	        
	        
	        System.out.println("Inserisci il numero di thread che vuoi creare: ");
	        int t = numero.nextInt();

	        System.out.println("Inserisci il numero fino a cui contare: ");
	        int n = numero.nextInt();

	        
	        Contatore contatore = new Contatore();

	       
	        Semaphore semaforo = new Semaphore(2);

	       
	        for (int i = 0; i < t; i++) {
	            Incrementatore incrementa = new Incrementatore(contatore, n / t, semaforo); // Distribuiamo il lavoro tra i thread
	            Thread thread = new Thread(incrementa, "Thread-" + (i + 1));
	            thread.start();
	        }

	        numero.close();
	}

}
