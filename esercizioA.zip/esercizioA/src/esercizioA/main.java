package esercizioA;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		 Scanner numero = new Scanner(System.in);
	        
	        System.out.println("Inserisci il numero di thread che vuoi creare: ");
	        int t = numero.nextInt();

	        System.out.println("Inserisci il numero fino a cui contare: ");
	        int n = numero.nextInt();

	       
	        Contatore contatore = new Contatore();

	        for (int i = 0; i < t; i++) {
	            Incrementatore incrementa = new Incrementatore(contatore, n / t); 
	            Thread thread = new Thread(incrementa, "Thread-" + (i + 1));
	            thread.start();
	        }

	        numero.close();
	    }
	}