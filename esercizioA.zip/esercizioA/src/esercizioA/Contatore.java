package esercizioA;

public class Contatore {
	 private int contatore = 0;

	    public synchronized void incrementa() {
	        contatore++;
	        System.out.println("Valore contatore: " + contatore);
	    }
}
