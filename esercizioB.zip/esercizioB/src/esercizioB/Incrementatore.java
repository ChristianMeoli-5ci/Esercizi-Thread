package esercizioB;

import java.util.concurrent.Semaphore;

public class Incrementatore implements Runnable {
    private Contatore contatore;
    private int n;
    private Semaphore semaforo;

    
    public Incrementatore(Contatore contatore, int n, Semaphore semaforo) {
        this.contatore = contatore;
        this.n = n;
        this.semaforo = semaforo;
    }
    
    @Override
    public void run() {
        try {
           
            semaforo.acquire();

            for (int i = 0; i < n; i++) {
                contatore.incrementa();
                try {
                    Thread.sleep(10); 
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        } catch (InterruptedException e) {
            e.printStackTrace();
        } 
        finally {
            semaforo.release();
        }
    }
    
}
