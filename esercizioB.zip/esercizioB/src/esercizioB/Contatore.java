package esercizioB;

public class Contatore {
	
    private int contatore = 0;

    // Metodo per incrementare il contatore in modo sicuro
    public synchronized void incrementa() {
        contatore++;
        System.out.println("Valore contatore: " + contatore);
    }

}
