package esercizioA;

public class Incrementatore implements Runnable {

	    private Contatore contatore;
	    private int n;

	    public Incrementatore(Contatore contatore, int n) {
	        this.contatore = contatore;
	        this.n = n;
	    }

	    @Override
	    public void run() {
	        for (int i = 0; i < n; i++) {
	            contatore.incrementa();
	        }
	    }
	}
