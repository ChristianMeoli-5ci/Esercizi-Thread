/**
 * 
 */
/**
 * 
 */
module esercizioA {
}